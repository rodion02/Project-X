var searchData=
[
  ['render_0',['render',['../classGame.html#a15ddd769261d923827a3cdf41499c843',1,'Game']]],
  ['run_1',['run',['../classGame.html#a1ab78f5ed0d5ea879157357cf2fb2afa',1,'Game']]]
];
